# Practical Business Python

This repository contains, code, notebooks and examples from https://pbpython.com
